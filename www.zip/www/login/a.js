function fn(){
   var fname= document.getElementById("fname").value;
  var lname= document.getElementById("lname").value;
  var email= document.getElementById("email").value;
  var p= document.getElementById("pass").value;
var d=document.getElementById("bday").value;
 var ph=document.getElementById("phonenum").value;
if(fname==""||fname==null ){
                         alert("enter first name" )
                         return false;
}

else if(lname==""||lname==null)
{
 alert("enter last name" )
                         return false;

}
else if(email==""||email==null)
{
 alert("enter email" )
                         return false;

}

else if(p==""||p==null)
{
 alert("enter password" )
                         return false;

}
     else if(d==""||d==null)
     {
         alert("enter date of birth")
         return false;
     }
       else if(ph==""||ph==null)
       {

       alert("enter phone numbetr")
       return false;

       }



return true;


}





var password = document.getElementById("pass")
  , confirm_password = document.getElementById("cpass");



function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;


